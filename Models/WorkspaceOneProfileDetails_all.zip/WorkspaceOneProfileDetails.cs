﻿using BBIHardwareSupport.MDM.WorkspaceOne.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBIHardwareSupport.MDM.WorkspaceOne.Models
{
    public sealed class WorkspaceOneProfileDetails
    {
        [JsonProperty("General")]
        public WorkspaceOneProfileGeneral? General { get; set; }

        // Example: present on some profile types
        [JsonProperty("AndroidForWorkCustomSettingsList")]
        public List<AndroidForWorkCustomSettingsItem>? AndroidForWorkCustomSettingsList { get; set; }

        // Example: present on some profile types (you showed this earlier)
        [JsonProperty("AndroidForWorkPermissions")]
        public AndroidForWorkPermissions? AndroidForWorkPermissions { get; set; }

        // Anything else we didn't explicitly model yet
        [JsonExtensionData]
        public IDictionary<string, JToken>? AdditionalSections { get; set; }
    }
}
