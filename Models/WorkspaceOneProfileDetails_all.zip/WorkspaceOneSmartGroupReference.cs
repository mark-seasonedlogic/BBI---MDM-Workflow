﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BBIHardwareSupport.MDM.WorkspaceOne.Models
{
    public class WorkspaceOneSmartGroupReference
    {
        public int SmartGroupId { get; set; }
        public string Name { get; set; } = string.Empty;
    }

}
